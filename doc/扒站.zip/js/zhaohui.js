$(function()
{
	//以下为样式设计
	$(".beijing").css('height',$(window).height());
	$(".denglu").css('top',$(window).height()*0.15);
	$(".denglu").css('left',($(window).width()-$(".denglu").width())/2);
})