$(function()
{
	//以下为样式设计
	$(".beijing").css('height',$(window).height());
	$(".denglu").css('height',$(".denglu").width()*0.34);
	$(".denglu").css('top',$(window).height()*0.3);
	$(".denglu").css('left',($(window).width()-$(".denglu").width())/2);
	
})









