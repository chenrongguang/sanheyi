/**
 * Created by XadillaX on 14-2-12.
 */
module.exports = require("./lib/ihuyi");
